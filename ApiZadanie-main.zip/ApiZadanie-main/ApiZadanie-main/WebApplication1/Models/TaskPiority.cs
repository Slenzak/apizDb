﻿namespace WebApplication1.Models
{
    public class TaskPiority
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public string Piority { get; set; }
    }
}
