﻿namespace WebApplication1.Models
{
    public class TaskStatus
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public string Status { get; set; }  
    }
}
