﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CommentController : Controller
    {
        public List<Comment> Comments = new List<Comment> { new Comment { Id = 1, TaskId=1, Title = "Comment1", Description = "Description",Author="DominikK" }, new Comment { Id = 2,TaskId=1, Author = "DominikK", Title="Comment2", Description = "Description" } };
        [HttpGet("{taskId}")]
        public Comment CommentsGet(int taskid)
        {
            return Comments.FirstOrDefault(x => x.Id == taskid);
        }
        [HttpPost("{author},{descripton},{taskid},{title}")]
        public List<Comment> CommentsSet(int taskid,string author,string title,string descripton)
        {
            Comments.Add(new Comment { Id = Comments.Count + 1, Author = author, TaskId= taskid,Title=title,Description=descripton });
            return Comments;
        }
        [HttpPut("{id},{title},{description}")]
        public List<Comment> CommentUpdate(int id, string title,string description)
        {
            var temp = Comments.FirstOrDefault(x => x.Id == id);
            if (temp != null)
            {
                temp.Title = title;
                temp.Description = description;
                return Comments;
            }
            return Comments;
        }
        [HttpDelete("{id}")]
        public List<Comment> CommentsDelete(int id)
        {
            var temp = Comments.FirstOrDefault(x => x.Id == id);
            if (temp != null)
            {
                Comments.Remove(temp);
                return Comments;
            }
            return Comments;
        }
    }
}
