﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : Controller
        {
        private readonly AppDataContext _appDataContext;
        public UsersController(AppDataContext appDataContext)
        {
            _appDataContext = appDataContext;
        }
        public List<User> Users = new List<User>{new User{Id = 1, Username = "DawidM", CreatedDate = new DateOnly(2015,12,2)},new User {Id= 2, Username = "DominikK",CreatedDate= new DateOnly(2016,12,03) } };
        [HttpGet]
        public List<User> UsersGet()
        {
            return _appDataContext.User.ToList();
        }
        [HttpGet("{id}")]
        public User UserGet(int id)
        {
            return _appDataContext.User.FirstOrDefault(x => x.Id == id); 
        }
        [HttpPost("{username}")]
        public List<User> UsersSet(string username)
        {
            Users.Add(new User { Id = Users.Count + 1, Username = username, CreatedDate = DateOnly.FromDateTime(DateTime.Today) });
            return Users;
        }
        [HttpPut("{id},{username}")]
        public List<User> UserUpdate(int id,string username)
        {
            var temp = Users.FirstOrDefault(x => x.Id == id);
            if (temp != null)
            {
                temp.Username = username;
                return Users;
            }
            return Users;
        }
        [HttpDelete("{id}")]
        public List<User> UsersDelete(int id) 
        {
            var temp = Users.FirstOrDefault(x=> x.Id == id);
            if (temp != null)
            {
                Users.Remove(temp);
                return Users;
            }
            return Users;
        }
    }
}
