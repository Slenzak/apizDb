﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using Task = WebApplication1.Models.Task;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskController : Controller
    {
        public List<Task> Tasks = new List<Task> { new Task { Id = 1, Title = "Task1", Description="description1" }, new Task { Id = 2, Title = "Task2", Description = "description2" } };
        [HttpGet]
        public List<Task> TasksGet()
        {
            return Tasks;
        }
        [HttpGet("{id}")]
        public Task TaskGet(int id)
        {
            return Tasks.FirstOrDefault(x => x.Id == id);
        }
        [HttpPost("{title},{description}")]
        public List<Task> TaskSet(string title,string description)
        {
            Tasks.Add(new Task { Id = Tasks.Count + 1, Title = title, Description = description });
            return Tasks;
        }
        [HttpPut("{id},{title},{description}")]
        public List<Task> TaskUpdate(int id, string title,string description)
        {
            var temp = Tasks.FirstOrDefault(x => x.Id == id);
            if (temp != null)
            {
                temp.Title = title;
                return Tasks;
            }
            return Tasks;
        }
        [HttpDelete("{id}")]
        public List<Task> TasksDelete(int id)
        {
            var temp = Tasks.FirstOrDefault(x => x.Id == id);
            if (temp != null)
            {
                Tasks.Remove(temp);
                return Tasks;
            }
            return Tasks;
        }
    }
}
