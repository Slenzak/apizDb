﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using TaskStatus = WebApplication1.Models.TaskStatus;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskStatusController : Controller
    {
        public List<TaskStatus> TaskStatuses = new List<TaskStatus> { new TaskStatus { Status = "done", TaskId = 1 }, new TaskStatus { Status = "In progress", TaskId = 2 } };
        [HttpGet]
        public List<TaskStatus> TaskStatusesGet()
        {
            return TaskStatuses;
        }
        [HttpGet("{taskid}")]
        public TaskStatus TaskStatusGet(int taskid)
        {
            return TaskStatuses.FirstOrDefault(x => x.TaskId == taskid);
        }
        [HttpPut("{taskid},{status}")]
        public List<TaskStatus> TaskStatusUpdate(int taskid, string status)
        {
            var temp = TaskStatuses.FirstOrDefault(x => x.TaskId == taskid);
            if (temp != null)
            {
                temp.Status = status;
                return TaskStatuses;
            }
            return TaskStatuses;
        }
    }
}
