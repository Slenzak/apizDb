﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
        [ApiController]
        [Route("api/[controller]")]
        public class TaskCattegoryController : Controller
        {
            public List<TaskCattegory> TaskCattegories = new List<TaskCattegory> { new TaskCattegory { Id = 1, Title = "category1" }, new TaskCattegory { Id = 2, Title = "category2" } };
            [HttpGet]
            public List<TaskCattegory> TaskCattegoriesGet()
            {
                return TaskCattegories;
            }
            [HttpGet("{id}")]
            public TaskCattegory TaskCattegoryGet(int id)
            {
                return TaskCattegories.FirstOrDefault(x => x.Id == id);
            }
            [HttpPost("{title}")]
            public List<TaskCattegory> TaskCattegoriesSet(string title)
            {
            TaskCattegories.Add(new TaskCattegory { Id = TaskCattegories.Count + 1, Title = title });
                return TaskCattegories;
            }
            [HttpPut("{id},{title}")]
            public List<TaskCattegory> TaskCattegoryUpdate(int id, string username)
            {
                var temp = TaskCattegories.FirstOrDefault(x => x.Id == id);
                if (temp != null)
                {
                    temp.Title = username;
                    return TaskCattegories;
                }
                return TaskCattegories;
            }
            [HttpDelete("{id}")]
            public List<TaskCattegory> TaskCattegoriesDelete(int id)
            {
                var temp = TaskCattegories.FirstOrDefault(x => x.Id == id);
                if (temp != null)
                {
                TaskCattegories.Remove(temp);
                    return TaskCattegories;
                }
                return TaskCattegories;
            }
        }
}
