﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class TaskPiorityController : Controller
    {
        public List<TaskPiority> TaskPiorities = new List<TaskPiority> { new TaskPiority { Piority = "first", TaskId=1 }, new TaskPiority { Piority = "When free", TaskId =2 } };
        [HttpGet]
        public List<TaskPiority> TaskPioritiesGet()
        {
            return TaskPiorities;
        }
        [HttpGet("{taskid}")]
        public TaskPiority TaskPiorityGet(int taskid)
        {
            return TaskPiorities.FirstOrDefault(x => x.TaskId == taskid);
        }
        [HttpPut("{taskid},{piority}")]
        public List<TaskPiority> TaskPiorityUpdate(int taskid, string piority)
        {
            var temp = TaskPiorities.FirstOrDefault(x => x.TaskId == taskid);
            if (temp != null)
            {
                temp.Piority = piority;
                return TaskPiorities;
            }
            return TaskPiorities;
        }
    }
}
